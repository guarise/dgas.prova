#define FAILED_ACQ_CRED "Failed to acquire credentials on "
#define FAILED_SEC_CONT "Failed to estabilish security context on "
